Browsebook 0.1.0 Android source candidate (2026-10-10)

This source candidate has not yet been submitted to Google Play.
Application ID: app.browsebook; version code: 10000.
Publisher: Heber Garza <mail@heberuriegas.com>

The binary Git patch contains ALL Browsebook changes relative to public
brave/brave-core commit 6205309948770ffbe1d53abd4119d9180c92d970, including the Android Configure-button fix.
It includes new files, binary assets, build scripts, tests, notices and documents.
No private repository access is required to obtain or reconstruct this source.

Upstream source: https://github.com/brave/brave-core/tree/6205309948770ffbe1d53abd4119d9180c92d970
Chromium: https://github.com/chromium/chromium/tree/b75a5a95ea1a1b55bdbfd6d9f42d47be7507fb8b
Chromium version: 153.0.8010.37
Reconstructed Brave tree before release-config override: 45de5de160f4feac5225228c961110aa9bc6c671

Reconstruct on Linux:
  git clone https://github.com/brave/brave-core.git browsebook-source
  cd browsebook-source
  git checkout --detach 6205309948770ffbe1d53abd4119d9180c92d970
  git apply --binary /absolute/path/to/browsebook.patch
  cp /absolute/path/to/release-config.json build/android/browsebook-release.json

Set up a Chromium/Brave Android checkout using the instructions in README.md and
  https://github.com/brave/brave-browser/wiki/Android-Development-Environment.
  Place this source at
  src/brave. Install the required Node, pnpm, Python and native toolchain, then
  synchronize Chromium and dependencies using the provided pnpm init/sync tools.
  DEPS and package.json identify upstream revisions and dependencies.

Build from src/brave:
  python3 tools/android/build_browsebook.py --src /absolute/path/to/src --release --run

The helper creates an unsigned ARM64 AAB. Signing keys, passwords and private
service credentials are intentionally not included. They are not required to
inspect or modify this source. Consult docs/browsebook-release.md for build and
release notes. Other architectures can use --target-arch x64.

Browsebook changes to MPL-covered files are licensed under MPL-2.0. See LICENSE.
Third-party components retain their own licenses and copyright notices. Upstream
license files and the in-app open-source credits remain part of the build.
